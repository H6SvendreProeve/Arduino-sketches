#ifndef Helper_H
#define Helper_H
#include <Arduino.h>

void printArray(int arr[], int arrSize);
bool doesThisIntArrayContain(int value, int* arr, int arrSize);

#endif
